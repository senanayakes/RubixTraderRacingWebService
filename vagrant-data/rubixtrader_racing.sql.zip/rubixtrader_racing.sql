-- phpMyAdmin SQL Dump
-- version 4.0.10deb1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Oct 12, 2015 at 01:17 AM
-- Server version: 5.5.44-0ubuntu0.14.04.1
-- PHP Version: 5.5.9-1ubuntu4.13

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `rubixtrader_racing`
--

-- --------------------------------------------------------

--
-- Table structure for table `contestant`
--

CREATE TABLE IF NOT EXISTS `contestant` (
  `contestant_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `event_id` bigint(20) unsigned NOT NULL,
  `runner_num` smallint(5) unsigned NOT NULL,
  `name` varchar(100) NOT NULL,
  `barrier` smallint(5) unsigned DEFAULT NULL,
  `status` varchar(30) NOT NULL,
  `finish_position` smallint(5) unsigned DEFAULT NULL,
  `rider` varchar(100) DEFAULT NULL,
  `trainer` varchar(100) DEFAULT NULL,
  `handicap` decimal(17,0) DEFAULT NULL,
  `handicap_str` varchar(100) DEFAULT NULL,
  `last_five_starts` varchar(100) DEFAULT NULL,
  `emergency` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`contestant_id`),
  KEY `event_id` (`event_id`),
  KEY `name` (`name`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=7 ;

--
-- Dumping data for table `contestant`
--

INSERT INTO `contestant` (`contestant_id`, `event_id`, `runner_num`, `name`, `barrier`, `status`, `finish_position`, `rider`, `trainer`, `handicap`, `handicap_str`, `last_five_starts`, `emergency`) VALUES
(1, 1, 1, 'HUSKARL', 1, '0', NULL, NULL, NULL, NULL, NULL, NULL, 0),
(2, 1, 2, 'LIQUID COURAGE', 9, '0', NULL, NULL, NULL, NULL, NULL, NULL, 0),
(3, 1, 3, 'LLAMAS IN PYJAMAS', 4, '0', NULL, NULL, NULL, NULL, NULL, NULL, 0),
(4, 1, 4, 'MATCH DAY', 8, '0', NULL, NULL, NULL, NULL, NULL, NULL, 0),
(5, 1, 5, 'OPTIMUS PAUL', 7, '0', NULL, NULL, NULL, NULL, NULL, NULL, 0),
(6, 1, 6, 'PRINCE OF POWER', 5, '0', NULL, NULL, NULL, NULL, NULL, NULL, 0);

-- --------------------------------------------------------

--
-- Table structure for table `dividend`
--

CREATE TABLE IF NOT EXISTS `dividend` (
  `dividend_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `pool_id` bigint(20) unsigned NOT NULL,
  `status` varchar(30) NOT NULL,
  `selections` varchar(50) NOT NULL,
  `amount` decimal(17,8) NOT NULL DEFAULT '0.00000000',
  PRIMARY KEY (`dividend_id`),
  KEY `pool_id` (`pool_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `event`
--

CREATE TABLE IF NOT EXISTS `event` (
  `event_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `venue_id` bigint(20) unsigned NOT NULL,
  `meeting_id` bigint(20) unsigned NOT NULL,
  `race_num` smallint(6) unsigned NOT NULL,
  `name` varchar(100) NOT NULL,
  `race_status` varchar(30) NOT NULL,
  `event_status` varchar(30) NOT NULL,
  `start_time` datetime NOT NULL,
  `surface` varchar(255) DEFAULT NULL,
  `weather` varchar(255) DEFAULT NULL,
  `distance` int(11) unsigned DEFAULT NULL,
  `prize_money` decimal(17,2) NOT NULL DEFAULT '0.00',
  `expected_dividends` int(10) unsigned DEFAULT NULL,
  PRIMARY KEY (`event_id`),
  KEY `start_time` (`start_time`),
  KEY `venue_id` (`venue_id`),
  KEY `meeting_id` (`meeting_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=5 ;

--
-- Dumping data for table `event`
--

INSERT INTO `event` (`event_id`, `venue_id`, `meeting_id`, `race_num`, `name`, `race_status`, `event_status`, `start_time`, `surface`, `weather`, `distance`, `prize_money`, `expected_dividends`) VALUES
(1, 4, 1, 1, 'Test Race', '0', '', '2015-10-07 14:30:00', NULL, NULL, NULL, 0.00, NULL),
(2, 4, 1, 2, 'Test Horse Two', '1', '1', '2015-10-14 00:00:00', 'Hard', 'Good', 1, 1111.00, 111111);

-- --------------------------------------------------------

--
-- Table structure for table `feed`
--

CREATE TABLE IF NOT EXISTS `feed` (
  `feed_id` int(11) NOT NULL,
  `name` varchar(50) NOT NULL,
  PRIMARY KEY (`feed_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `feed`
--

INSERT INTO `feed` (`feed_id`, `name`) VALUES
(-3, 'PA'),
(-2, 'LUXBOOK'),
(-1, 'WIFT');

-- --------------------------------------------------------

--
-- Table structure for table `fixed_odds`
--

CREATE TABLE IF NOT EXISTS `fixed_odds` (
  `fixed_odds_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `event_id` bigint(20) unsigned NOT NULL,
  `market_id` bigint(20) unsigned NOT NULL,
  `contestant_id` bigint(20) unsigned NOT NULL,
  `source_id` int(11) unsigned NOT NULL,
  `win_price` decimal(17,8) NOT NULL DEFAULT '0.00000000',
  `place_price` decimal(17,8) NOT NULL DEFAULT '0.00000000',
  PRIMARY KEY (`fixed_odds_id`),
  UNIQUE KEY `event_id` (`event_id`),
  UNIQUE KEY `market_id` (`market_id`),
  UNIQUE KEY `contestant_id` (`contestant_id`),
  UNIQUE KEY `source_id` (`source_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `market`
--

CREATE TABLE IF NOT EXISTS `market` (
  `market_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `event_id` bigint(20) unsigned NOT NULL,
  `name` varchar(75) NOT NULL,
  PRIMARY KEY (`market_id`),
  KEY `event_id` (`event_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `meeting`
--

CREATE TABLE IF NOT EXISTS `meeting` (
  `meeting_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `venue_id` bigint(20) unsigned NOT NULL,
  `name` varchar(100) NOT NULL,
  `meeting_date` date NOT NULL,
  `timezone_at_venue` varchar(50) NOT NULL,
  PRIMARY KEY (`meeting_id`),
  UNIQUE KEY `meeting_id` (`meeting_id`),
  KEY `venue_id` (`venue_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `meeting`
--

INSERT INTO `meeting` (`meeting_id`, `venue_id`, `name`, `meeting_date`, `timezone_at_venue`) VALUES
(1, 4, 'Sir Rupert Clarke Stakes', '2015-10-07', 'GMT+9:30'),
(2, 12, 'Test GreyHound Racing ', '2015-10-08', 'GMT  000000 '),
(3, 18, 'TEST Harness Meeting', '2015-10-14', '"TTTTTTTTT"');

-- --------------------------------------------------------

--
-- Table structure for table `pool`
--

CREATE TABLE IF NOT EXISTS `pool` (
  `pool_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `pool_type_id` int(10) unsigned NOT NULL,
  `source_id` int(10) unsigned NOT NULL,
  `pool_status` varchar(30) NOT NULL,
  `total` bigint(20) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`pool_id`),
  KEY `pool_type_id` (`pool_type_id`),
  KEY `source_id` (`source_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `pool_events`
--

CREATE TABLE IF NOT EXISTS `pool_events` (
  `pool_events_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `event_id` bigint(20) unsigned NOT NULL,
  `pool_id` bigint(20) unsigned NOT NULL,
  `substitute` smallint(5) unsigned NOT NULL,
  PRIMARY KEY (`pool_events_id`),
  UNIQUE KEY `event_id` (`event_id`),
  UNIQUE KEY `pool_id` (`pool_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `pool_type`
--

CREATE TABLE IF NOT EXISTS `pool_type` (
  `pool_type_id` int(10) unsigned NOT NULL,
  `name` varchar(30) NOT NULL,
  PRIMARY KEY (`pool_type_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `pool_type`
--

INSERT INTO `pool_type` (`pool_type_id`, `name`) VALUES
(1, 'Win'),
(2, 'Place'),
(3, 'Quinella'),
(4, 'Exacta'),
(5, 'Daily Double'),
(6, 'Running Double'),
(7, 'First Four'),
(8, 'Quadrella'),
(9, 'Trifecta');

-- --------------------------------------------------------

--
-- Table structure for table `source`
--

CREATE TABLE IF NOT EXISTS `source` (
  `source_id` int(10) unsigned NOT NULL,
  `name` varchar(50) CHARACTER SET utf32 NOT NULL,
  PRIMARY KEY (`source_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `source`
--

INSERT INTO `source` (`source_id`, `name`) VALUES
(1, 'Override'),
(2, 'APN'),
(3, 'Luxbook DVP'),
(4, 'SIS'),
(5, 'TabcorpNSW'),
(6, 'TabcorpVIC'),
(7, 'UniTAB');

-- --------------------------------------------------------

--
-- Table structure for table `sport`
--

CREATE TABLE IF NOT EXISTS `sport` (
  `sport_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(75) NOT NULL,
  PRIMARY KEY (`sport_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `sport`
--

INSERT INTO `sport` (`sport_id`, `name`) VALUES
(1, 'Horse Racing'),
(2, 'Greyhound Racing'),
(3, 'Harness Racing');

-- --------------------------------------------------------

--
-- Table structure for table `venue`
--

CREATE TABLE IF NOT EXISTS `venue` (
  `venue_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `sport_id` int(10) unsigned NOT NULL,
  `name` varchar(75) NOT NULL,
  PRIMARY KEY (`venue_id`),
  UNIQUE KEY `name` (`name`,`sport_id`),
  KEY `sport_id` (`sport_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=23 ;

--
-- Dumping data for table `venue`
--

INSERT INTO `venue` (`venue_id`, `sport_id`, `name`) VALUES
(11, 2, 'ADDINGTON'),
(12, 2, 'ARMIDALE'),
(17, 3, 'ARMIDALE'),
(18, 3, 'AVONDALE'),
(4, 1, 'BALLARAT'),
(13, 2, 'BALLARAT'),
(19, 3, 'BALLARAT'),
(9, 1, 'BELMONT'),
(14, 2, 'BENDIGO'),
(15, 2, 'CANBERRA'),
(5, 1, 'CAULFIELD'),
(2, 1, 'FLEMINGTON'),
(10, 1, 'GEELONG'),
(16, 2, 'GEELONG'),
(21, 3, 'GEELONG'),
(8, 1, 'GOSFORD'),
(20, 3, 'MANAWATU'),
(22, 3, 'MOONEY VALLEY'),
(7, 1, 'SANDOWN'),
(3, 1, 'WARWICK FARM');

-- --------------------------------------------------------

--
-- Table structure for table `venue_alias`
--

CREATE TABLE IF NOT EXISTS `venue_alias` (
  `venue_alias_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `feed_id` int(11) NOT NULL,
  `venue_id` bigint(20) unsigned NOT NULL,
  `name` varchar(75) CHARACTER SET utf32 NOT NULL,
  PRIMARY KEY (`venue_alias_id`),
  KEY `feed_id` (`feed_id`),
  KEY `venue_id` (`venue_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=9 ;

--
-- Dumping data for table `venue_alias`
--

INSERT INTO `venue_alias` (`venue_alias_id`, `feed_id`, `venue_id`, `name`) VALUES
(1, -1, 2, 'FLEMINGTON'),
(2, -1, 3, 'WARWICK FARM'),
(3, -1, 4, 'BALLARAT'),
(4, -1, 5, 'CAULFIELD'),
(5, -1, 7, 'SANDOWN'),
(6, -1, 8, 'GOSFORD'),
(7, -1, 9, 'BELMONT'),
(8, -1, 10, 'GEELONG');

--
-- Constraints for dumped tables
--

--
-- Constraints for table `contestant`
--
ALTER TABLE `contestant`
  ADD CONSTRAINT `contestant_ibfk_1` FOREIGN KEY (`event_id`) REFERENCES `event` (`event_id`);

--
-- Constraints for table `dividend`
--
ALTER TABLE `dividend`
  ADD CONSTRAINT `dividend_ibfk_1` FOREIGN KEY (`pool_id`) REFERENCES `pool` (`pool_id`);

--
-- Constraints for table `event`
--
ALTER TABLE `event`
  ADD CONSTRAINT `event_ibfk_1` FOREIGN KEY (`venue_id`) REFERENCES `venue` (`venue_id`),
  ADD CONSTRAINT `event_ibfk_2` FOREIGN KEY (`meeting_id`) REFERENCES `meeting` (`meeting_id`);

--
-- Constraints for table `fixed_odds`
--
ALTER TABLE `fixed_odds`
  ADD CONSTRAINT `fixed_odds_ibfk_1` FOREIGN KEY (`event_id`) REFERENCES `event` (`event_id`),
  ADD CONSTRAINT `fixed_odds_ibfk_2` FOREIGN KEY (`market_id`) REFERENCES `market` (`market_id`),
  ADD CONSTRAINT `fixed_odds_ibfk_3` FOREIGN KEY (`contestant_id`) REFERENCES `contestant` (`contestant_id`),
  ADD CONSTRAINT `fixed_odds_ibfk_4` FOREIGN KEY (`source_id`) REFERENCES `source` (`source_id`);

--
-- Constraints for table `market`
--
ALTER TABLE `market`
  ADD CONSTRAINT `market_ibfk_1` FOREIGN KEY (`event_id`) REFERENCES `event` (`event_id`);

--
-- Constraints for table `meeting`
--
ALTER TABLE `meeting`
  ADD CONSTRAINT `meeting_ibfk_1` FOREIGN KEY (`venue_id`) REFERENCES `venue` (`venue_id`);

--
-- Constraints for table `pool`
--
ALTER TABLE `pool`
  ADD CONSTRAINT `pool_ibfk_1` FOREIGN KEY (`pool_type_id`) REFERENCES `pool_type` (`pool_type_id`),
  ADD CONSTRAINT `pool_ibfk_2` FOREIGN KEY (`source_id`) REFERENCES `source` (`source_id`);

--
-- Constraints for table `pool_events`
--
ALTER TABLE `pool_events`
  ADD CONSTRAINT `pool_events_ibfk_1` FOREIGN KEY (`event_id`) REFERENCES `event` (`event_id`),
  ADD CONSTRAINT `pool_events_ibfk_2` FOREIGN KEY (`pool_id`) REFERENCES `pool` (`pool_id`);

--
-- Constraints for table `venue`
--
ALTER TABLE `venue`
  ADD CONSTRAINT `venue_ibfk_1` FOREIGN KEY (`sport_id`) REFERENCES `sport` (`sport_id`);

--
-- Constraints for table `venue_alias`
--
ALTER TABLE `venue_alias`
  ADD CONSTRAINT `venue_alias_ibfk_1` FOREIGN KEY (`venue_id`) REFERENCES `venue` (`venue_id`),
  ADD CONSTRAINT `venue_alias_ibfk_2` FOREIGN KEY (`feed_id`) REFERENCES `feed` (`feed_id`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
